# Superstore Returns Analysis

## Project Overview
Analysis of return patterns at Superstore to identify root causes and reduce return volume.

## Tableau Public Link
[View Dashboard on Tableau Public](https://public.tableau.com/app/profile/michelle.harris2773/viz/Sprint5Project_17696556097610/SuperstoreReturns?publish=yes)

## Presentation Video
[Watch my presentation here](https://www.loom.com/share/0cf58a1d719b4b79893b472cf72e801d)

![MockUp 1](https://drive.google.com/file/d/1m4lGvOaNQjx7k_XCfy_XDrZ8dxGDTWx6/view?usp=drive_link)
![MockUP 2](https://drive.google.com/file/d/1g4d3Up_OuCDnG6vlm8_knHwgi2OIYlAf/view?usp=drive_link
![MockUp 3](https://drive.google.com/file/d/1aKMMtp1vozfZ3wzdJaIhdHeFqsM2kV4A/view?usp=drive_link)

## Key Findings
- Brief summary of your main insights about returns
- Root causes identified
- Recommended actions

## Files Included
- Tableau workbook (.twbx)
- Dashboard screenshots
- Mock-up sketches